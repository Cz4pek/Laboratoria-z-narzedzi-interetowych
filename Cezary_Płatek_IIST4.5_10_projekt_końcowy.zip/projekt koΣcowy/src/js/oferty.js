function ofertaSwiat() {

    var img1 = "https://images.unsplash.com/photo-1530454675450-96d79a032eec?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80";
    var title1 = 'Władywostok';
    var summary1 = 'Lorem ipsum';
    var bodytitle1 = 'Wycieczka do Władywostoku!!';
    var info1 = 'Informacje o wycieczce do Władywostoku Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid atque cum dicta dolore et magni maiores minima nemo nisi non, nostrum quod. Autem dolorem laborum magnam, perspiciatis placeat quam unde. ';
    var footer1 = '2000 zł/os';
    //var tresc = '';
    $('#wroclaw').attr('src', img1);
    $('#title1').html(title1);
    $('#summary1').html(summary1);
    $('#bodytitle1').html(bodytitle1);
    $('#info1').html(info1);
    $('#footer1').html(footer1);

    var img2 = "https://images.unsplash.com/photo-1566766189268-ecac9118f2b7?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80";
    var title2 = 'Kotte';
    var summary2 = 'Lorem ipsum';
    var bodytitle2 = 'Wycieczka do Kotte!';
    var info2 = 'Informacje o wycieczce do Kotte Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid atque cum dicta dolore et magni maiores minima nemo nisi non, nostrum quod. Autem dolorem laborum magnam, perspiciatis placeat quam unde.';
    var footer2 = '3500 zł/os';
    $('#zakopane').attr('src', img2);
    $('#title2').html(title2);
    $('#summary2').html(summary2);
    $('#bodytitle2').html(bodytitle2);
    $('#info2').html(info2);
    $('#footer2').html(footer2);

    var img3 = "https://images.unsplash.com/photo-1557046758-ad43a87f16b2?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80";
    var title3 = 'Pekin';
    var summary3 = 'Lorem ipsum';
    var bodytitle3 = 'Wycieczka do Pekinu!';
    var info3 = 'Informacje o wycieczce do Pekinu Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid atque cum dicta dolore et magni maiores minima nemo nisi non, nostrum quod. Autem dolorem laborum magnam, perspiciatis placeat quam unde.';
    var footer3 = '5000 zł/os';
    $('#krakow').attr('src', img3);
    $('#title3').html(title3);
    $('#summary3').html(summary3);
    $('#bodytitle3').html(bodytitle3);
    $('#info3').html(info3);
    $('#footer3').html(footer3);

    var img4 = "https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1350&q=80";
    var title4 = 'Bali';
    var summary4 = 'Lorem ipsum';
    var bodytitle4 = 'Wycieczka na Balli!';
    var info4 = 'Informacje o wycieczce na Balli Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid atque cum dicta dolore et magni maiores minima nemo nisi non, nostrum quod. Autem dolorem laborum magnam, perspiciatis placeat quam unde.';
    var footer4 = '300 zł/os';
    $('#gadnsk').attr('src', img4);
    $('#title4').html(title4);
    $('#summary4').html(summary4);
    $('#bodytitle4').html(bodytitle4);
    $('#info4').html(info4);
    $('#footer4').html(footer4);

    $('#kraj').removeClass('active');
    $('#europa').removeClass('active');
    $('#swiat').addClass('active');
}


function ofertakKraj() {

    var img1 = "https://images.unsplash.com/photo-1532157345990-d3ab4df99902?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=776&q=80";
    var title1 = 'Wrocław <span class="badge badge-success">Last minute!</span>';
    var summary1 = '7 dni w 3 gwiazdkowym hotelu';
    var bodytitle1 = 'Wycieczka do Wrocławia!';
    var info1 = 'Informacje o wycieczce do Wrocławia Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid atque cum dicta dolore et magni maiores minima nemo nisi non, nostrum quod. Autem dolorem laborum magnam, perspiciatis placeat quam unde.';
    var footer1 = '1199 zł/os';
    $('#wroclaw').attr('src', img1);
    $('#title1').html(title1);
    $('#summary1').html(summary1);
    $('#bodytitle1').html(bodytitle1);
    $('#info1').html(info1);
    $('#footer1').html(footer1);

    var img2 = "https://images.unsplash.com/photo-1475139977302-d5bd42365d8b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1053&q=80";
    var title2 = 'Zakopane';
    var summary2 = 'Weekend w górach, w pensjonacie';
    var bodytitle2 = 'Wycieczka w góry!';
    var info2 = 'Informacje o wycieczce w góry Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid atque cum dicta dolore et magni maiores minima nemo nisi non, nostrum quod. Autem dolorem laborum magnam, perspiciatis placeat quam unde.';
    var footer2 = '450 zł/os';
    $('#zakopane').attr('src', img2);
    $('#title2').html(title2);
    $('#summary2').html(summary2);
    $('#bodytitle2').html(bodytitle2);
    $('#info2').html(info2);
    $('#footer2').html(footer2);

    var img3 = "https://images.unsplash.com/photo-1563627042004-362887667513?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=968&q=80";
    var title3 = 'Kraków';
    var summary3 = 'City break w krakowie';
    var bodytitle3 = 'Wycieczka do Krakowa!!';
    var info3 = 'Informacje o wycieczce do Krakowa Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid atque cum dicta dolore et magni maiores minima nemo nisi non, nostrum quod. Autem dolorem laborum magnam, perspiciatis placeat quam unde.';
    var footer3 = '800 zł/os';
    $('#krakow').attr('src', img3);
    $('#title3').html(title3);
    $('#summary3').html(summary3);
    $('#bodytitle3').html(bodytitle3);
    $('#info3').html(info3);
    $('#footer3').html(footer3);

    var img4 = "https://images.unsplash.com/photo-1505659645613-28348af82dd6?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80";
    var title4 = 'Gdańsk';
    var summary4 = 'Budżetowy wyjazd do Gadńska na 5 dni';
    var bodytitle4 = 'Wycieczka do Gdańska!';
    var info4 = 'Informacje o wycieczce do Gdańska Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid atque cum dicta dolore et magni maiores minima nemo nisi non, nostrum quod. Autem dolorem laborum magnam, perspiciatis placeat quam unde.';
    var footer4 = '600 zł/os';
    $('#gadnsk').attr('src', img4);
    $('#title4').html(title4);
    $('#summary4').html(summary4);
    $('#bodytitle4').html(bodytitle4);
    $('#info4').html(info4);
    $('#footer4').html(footer4);

    $('#kraj').addClass('active');
    $('#europa').removeClass('active');
    $('#swiat').removeClass('active');
}

function ofertaEuropa() {
    var img1 = "https://images.unsplash.com/photo-1523906921802-b5d2d899e93b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=605&q=80";
    var title1 = 'Wenecja <span class="badge badge-success">Last minute!</span>';
    var summary1 = 'Lorem ipsum';
    var bodytitle1 = 'Wycieczka do Wenecji!';
    var info1 = 'Informacje o wycieczce do Wenecji Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid atque cum dicta dolore et magni maiores minima nemo nisi non, nostrum quod. Autem dolorem laborum magnam, perspiciatis placeat quam unde.';
    var footer1 = '2300 zł/os';
    $('#wroclaw').attr('src', img1);
    $('#title1').html(title1);
    $('#summary1').html(summary1);
    $('#bodytitle1').html(bodytitle1);
    $('#info1').html(info1);
    $('#footer1').html(footer1);

    var img2 = "https://images.unsplash.com/photo-1583458978661-3cc668f8249c?ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80";
    var title2 = 'Reykjavik';
    var summary2 = 'Lorem ipsum';
    var bodytitle2 = 'Wycieczka w góry!';
    var info2 = 'Informacje o wycieczce do Reykjaviku Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid atque cum dicta dolore et magni maiores minima nemo nisi non, nostrum quod. Autem dolorem laborum magnam, perspiciatis placeat quam unde.';
    var footer2 = '3000 zł/os';
    $('#zakopane').attr('src', img2);
    $('#title2').html(title2);
    $('#summary2').html(summary2);
    $('#bodytitle2').html(bodytitle2);
    $('#info2').html(info2);
    $('#footer2').html(footer2);

    var img3 = "https://images.unsplash.com/photo-1549144511-f099e773c147?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80";
    var title3 = 'Paryż';
    var summary3 = 'Lorem ipsum';
    var bodytitle3 = 'Wycieczka do Paryża!';
    var info3 = 'Informacje o wycieczce do Paryża Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid atque cum dicta dolore et magni maiores minima nemo nisi non, nostrum quod. Autem dolorem laborum magnam, perspiciatis placeat quam unde.';
    var footer3 = '1500 zł/os';
    $('#krakow').attr('src', img3);
    $('#title3').html(title3);
    $('#summary3').html(summary3);
    $('#bodytitle3').html(bodytitle3);
    $('#info3').html(info3);
    $('#footer3').html(footer3);

    var img4 = "https://images.unsplash.com/photo-1491166617655-0723a0999cfc?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1950&q=80";
    var title4 = 'Nicea';
    var summary4 = 'Lorem ipsum';
    var bodytitle4 = 'Wycieczka do Nicei!';
    var info4 = 'Informacje o wycieczce do Nicei Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid atque cum dicta dolore et magni maiores minima nemo nisi non, nostrum quod. Autem dolorem laborum magnam, perspiciatis placeat quam unde.';
    var footer4 = '2000 zł/os';
    $('#gadnsk').attr('src', img4);
    $('#title4').html(title4);
    $('#summary4').html(summary4);
    $('#bodytitle4').html(bodytitle4);
    $('#info4').html(info4);
    $('#footer4').html(footer4);

    $('#kraj').removeClass('active');
    $('#europa').addClass('active');
    $('#swiat').removeClass('active');
}

function ofertaBrak() {

    let tresc = '<h2>Brak następnych ofert</h2>';
    $('.card').css('display', 'none');
    $('#brak').css('display', 'block');

}